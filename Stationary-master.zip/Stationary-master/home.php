<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
        <link rel="stylesheet" href="./css/style1.css">
    <title>HOME PAGE</title>
</head>
<?php include 'navbar.php';   ?>
<body>
<div class="one">
GET INSTANT DISCOUNT UPTO 40%<br>
SHOP NOW!
</div>
<div class="two">
<p>
<p id="line1">Check out our Products</p><br>
which are of very good quality but available only in bulk.</p>
</div>
<div class="footer">
<p>
<b>Contact Us:</b><br>
<i class="fa fa-facebook" aria-hidden="true"></i>&nbsp;&nbsp;&nbsp;
<i class="fa fa-instagram" aria-hidden="true"></i>&nbsp;&nbsp;&nbsp;
<i class="fa fa-twitter" aria-hidden="true"></i>&nbsp;&nbsp;&nbsp;<br>
Legal Stuff&nbsp;&nbsp;&nbsp;&nbsp; Privacy Policy
</p>   
</div>
</body>
</html>



