# Stationary 
![logo2](https://user-images.githubusercontent.com/56539752/76159138-5ed5e280-6143-11ea-898f-3df1874e6526.png)



### Introduction

As you know, e-commerce websites are generally used for selling electronic gadgets and clothing products.To break this trend, I have brought a new concept of selling stationary products.
I have put in lots of efforts to give my website a quite good user interface. As stationary products are very cheap, this website provides the sale of products in bulk rather than selling it in smaller quantities,which can be a drawback to such websites. 

### Development Tools

* We have used Visual Studio Code as our text editor
* Language: CSS, HTML, JavaScript, PHP, SQL
* We have used Apache server (local host: XAMPP)
* Frameworks and libraries: Bootstrap and font awesome.
 
### Features

* Secure login-logout (password encrypted)
* Fully Responsive
* User friendly
* link to use this website is http://stationary.freesite.vip

